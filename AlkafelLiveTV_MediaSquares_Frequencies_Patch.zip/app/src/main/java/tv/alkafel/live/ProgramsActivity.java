package tv.alkafel.live;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class ProgramsActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(5,5,5));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(14), dp(14), dp(24));
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView title = text("برامج القناة", 22, true, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, dp(62)));

        TextView soon = text("برامج القناة\nقريبًا", 20, true, Color.rgb(210,170,75));
        soon.setGravity(Gravity.CENTER);
        soon.setBackgroundColor(Color.rgb(18,18,18));
        page.addView(soon, new LinearLayout.LayoutParams(-1, dp(180)));

        TextView back = text("رجوع", 15, true, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setBackgroundColor(Color.rgb(170,0,0));
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(52));
        bp.setMargins(0, dp(14), 0, 0);
        page.addView(back, bp);

        scroll.addView(page);
        setContentView(scroll);
    }
    private TextView text(String s, int size, boolean bold, int color) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); v.setPadding(dp(8),dp(8),dp(8),dp(8));
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD); return v;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
}
