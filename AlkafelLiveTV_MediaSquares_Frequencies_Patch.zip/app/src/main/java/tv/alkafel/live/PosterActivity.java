package tv.alkafel.live;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class PosterActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(5,5,5));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(12), dp(12), dp(12), dp(24));
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView title = new TextView(this);
        title.setText("الإعلانات والبوسترات");
        title.setTextColor(Color.WHITE);
        title.setTextSize(21);
        title.setGravity(Gravity.CENTER);
        title.setPadding(8, 12, 8, 18);
        page.addView(title);

        addPoster(page, "poster_app_1");
        addPoster(page, "poster_youtube");
        addPoster(page, "poster_app_2");

        TextView back = new TextView(this);
        back.setText("رجوع");
        back.setTextColor(Color.WHITE);
        back.setTextSize(15);
        back.setGravity(Gravity.CENTER);
        back.setBackgroundColor(Color.rgb(170,0,0));
        back.setPadding(8, 14, 8, 14);
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(52));
        bp.setMargins(0, dp(12), 0, 0);
        page.addView(back, bp);

        scroll.addView(page);
        setContentView(scroll);
    }

    private void addPoster(LinearLayout page, String name) {
        ImageView image = new ImageView(this);
        int id = getResources().getIdentifier(name, "drawable", getPackageName());
        image.setImageResource(id);
        image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, dp(10));
        page.addView(image, lp);
    }

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
}
