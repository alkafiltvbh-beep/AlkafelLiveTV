package tv.alkafel.live;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class PosterActivity extends Activity {
    private static final int BG = Color.rgb(5,5,5);
    private static final int RED = Color.rgb(170,0,0);
    private static final int GOLD = Color.rgb(210,170,75);

    private final int[] posters = {
        R.drawable.poster_app_1,
        R.drawable.poster_youtube,
        R.drawable.poster_app_2
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(10),dp(10),dp(10),dp(24));
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView back = new TextView(this);
        back.setText("‹  إعلانات القناة والبوسترات");
        back.setTextColor(Color.WHITE);
        back.setTextSize(20);
        back.setGravity(Gravity.CENTER);
        back.setPadding(8,12,8,12);
        back.setOnClickListener(v -> finish());
        page.addView(back,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(58)));

        int selected=getIntent().getIntExtra("poster_index",-1);
        if(selected>=0 && selected<posters.length){ addPoster(page,posters[selected]); }
        else for(int id:posters) addPoster(page,id);
        scroll.addView(page);
        setContentView(scroll);
    }

    private void addPoster(LinearLayout page,int id){
        ImageView image=new ImageView(this);
        image.setImageResource(id);
        image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        page.addView(image,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
