# Alkafel Live TV - R8 rules
# Keep Android components referenced from the manifest.
-keep class tv.alkafel.live.MainActivity { *; }
-keep class tv.alkafel.live.LabbaikActivity { *; }
-keep class tv.alkafel.live.ZiyaratActivity { *; }
-keep class tv.alkafel.live.StudioActivity { *; }

# Media3/ExoPlayer uses reflection/service loading in parts of the stack.
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
