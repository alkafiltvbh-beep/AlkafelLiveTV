plugins {
    id("com.android.application")
}

android {
    namespace = "tv.alkafel.live"
    compileSdk = 35

    defaultConfig {
        applicationId = "tv.alkafel.live"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"
    }
}

dependencies {
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")
}
