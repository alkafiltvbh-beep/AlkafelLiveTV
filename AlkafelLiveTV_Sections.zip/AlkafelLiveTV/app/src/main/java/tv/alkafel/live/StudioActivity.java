package tv.alkafel.live;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class StudioActivity extends Activity {
    private static final int BG = Color.rgb(5,5,5);
    private static final int CARD = Color.rgb(18,18,18);
    private static final int RED = Color.rgb(180,0,0);
    private static final int GOLD = Color.rgb(210,170,75);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(18), dp(16), dp(24));
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(page);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = text("‹", 30, true, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        TextView title = text("استديو الكافل", 25, true, Color.WHITE);
        title.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(58), 1f));
        page.addView(top);

        TextView subtitle = text("إنتاجات وبرامج استديو الكافل", 14, false, GOLD);
        subtitle.setGravity(Gravity.RIGHT);
        page.addView(subtitle);

        addCard(page, "إنتاجات الاستديو", "أحدث الأعمال");
        addCard(page, "برامج خاصة", "برامج من إنتاج الاستديو");
        addCard(page, "فواصل وهوية القناة", "مقدمات وفواصل");
        addCard(page, "أرشيف الاستديو", "أعمال سابقة");

        setContentView(scroll);
    }

    private void addCard(LinearLayout page, String title, String sub) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), RED);
        c.setBackground(bg);

        TextView t = text(title, 19, true, Color.WHITE);
        TextView s = text(sub, 13, false, Color.LTGRAY);
        c.addView(t);
        c.addView(s);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_        addCard(page, "إنتاجات الاستديو", "أحدث الأعمال");
        addCard(page, "برامج خاصة", "برامج من إنتاج الاستديو");
        addCard(page, "فواصل وهوية القناة", "مقدمات وفواصل");
        addCard(page, "أرشيف الاستديو", "أعمال سابقة"););
        lp.setMargins(0, dp(8), 0, dp(8));
        page.addView(c, lp);
    }

    private TextView text(String s, int size, boolean bold, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(dp(8), dp(8), dp(8), dp(8));
        v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
