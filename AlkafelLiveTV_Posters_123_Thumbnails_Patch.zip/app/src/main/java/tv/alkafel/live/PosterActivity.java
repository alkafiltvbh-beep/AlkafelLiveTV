package tv.alkafel.live;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class PosterActivity extends Activity {

    private final String[] posterNames = {
            "poster_app_1",
            "poster_youtube",
            "poster_app_2"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(5,5,5));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(12), dp(10), dp(12), dp(24));
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView title = text("الإعلانات والبوسترات", 21, true, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, dp(60)));

        TextView hint = text("اضغط على أي بوستر لعرضه بالحجم الكامل", 12, false, Color.rgb(180,180,180));
        hint.setGravity(Gravity.CENTER);
        page.addView(hint, new LinearLayout.LayoutParams(-1, dp(38)));

        // Three compact posters are visible together inside the app.
        for (String name : posterNames) {
            addThumbnail(page, name);
        }

        TextView back = text("رجوع", 15, true, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setBackground(roundBg(Color.rgb(170,0,0), 12));
        back.setOnClickListener(v -> finish());

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(52));
        bp.setMargins(0, dp(12), 0, 0);
        page.addView(back, bp);

        scroll.addView(page);
        setContentView(scroll);
    }

    private void addThumbnail(LinearLayout page, String name) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(6), dp(6), dp(6), dp(6));
        card.setBackground(roundBg(Color.rgb(18,18,18), 14));

        ImageView image = new ImageView(this);
        int id = getResources().getIdentifier(name, "drawable", getPackageName());
        image.setImageResource(id);
        image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);

        card.addView(image, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(150)));

        TextView label = text("عرض البوستر", 11, true, Color.WHITE);
        label.setGravity(Gravity.CENTER);
        card.addView(label, new LinearLayout.LayoutParams(-1, dp(34)));

        card.setOnClickListener(v -> showFullPoster(name));

        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(194));
        cp.setMargins(0, dp(5), 0, dp(5));
        page.addView(card, cp);
    }

    private void showFullPoster(String name) {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.BLACK);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(8), dp(8), dp(8), dp(18));
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ImageView image = new ImageView(this);
        int id = getResources().getIdentifier(name, "drawable", getPackageName());
        image.setImageResource(id);
        image.setAdjustViewBounds(true);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        page.addView(image, new LinearLayout.LayoutParams(-1, -2));

        TextView back = text("رجوع إلى البوسترات", 14, true, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setBackground(roundBg(Color.rgb(170,0,0), 12));
        back.setOnClickListener(v -> setContentView(scroll));

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(52));
        bp.setMargins(0, dp(12), 0, 0);
        page.addView(back, bp);

        scroll.addView(page);
        setContentView(scroll);
    }

    private TextView text(String s, int size, boolean bold, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(dp(8), dp(5), dp(8), dp(5));
        if (bold) {
            v.setTypeface(android.graphics.Typeface.DEFAULT,
                    android.graphics.Typeface.BOLD);
        }
        return v;
    }

    private GradientDrawable roundBg(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int v) {
        return (int)(v * getResources().getDisplayMetrics().density + .5f);
    }
}
