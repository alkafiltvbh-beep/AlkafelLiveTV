package tv.alkafel.live;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class ZiyaratActivity extends Activity {
    private static final int BG=Color.rgb(5,5,5), CARD=Color.rgb(18,18,18), RED=Color.rgb(180,0,0), GOLD=Color.rgb(210,170,75);
    private MediaPlayer player;
    private TextView activeButton;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(BG); scroll.setFillViewport(true);
        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(16),dp(18),dp(16),dp(28)); page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); scroll.addView(page);
        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back=text("‹",30,true,Color.WHITE); back.setGravity(Gravity.CENTER); back.setOnClickListener(v->finish()); top.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));
        TextView title=text("الأدعية والزيارات",25,true,Color.WHITE); title.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); top.addView(title,new LinearLayout.LayoutParams(0,dp(58),1f)); page.addView(top);
        TextView sub=text("6 صوتيات",14,false,GOLD); sub.setGravity(Gravity.RIGHT); page.addView(sub);

        addTrack(page,"دعاء التوسل",R.raw.dua_tawassul);
        addTrack(page,"دعاء الفرج",R.raw.dua_faraj);
        addTrack(page,"دعاء الصباح",R.raw.dua_sabah);
        addTrack(page,"زيارة أمين الله",R.raw.ziyarat_amin_allah);
        addTrack(page,"زيارة عاشوراء",R.raw.ziyarat_ashura);
        addTrack(page,"زيارة وارث",R.raw.ziyarat_warith);
        setContentView(scroll);
    }

    private void addTrack(LinearLayout page,String title,int resId){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(12),dp(10),dp(12),dp(10));
        GradientDrawable bg=new GradientDrawable(); bg.setColor(CARD); bg.setCornerRadius(dp(16)); bg.setStroke(dp(1),RED); card.setBackground(bg);
        TextView play=text("▶",21,true,Color.WHITE); play.setGravity(Gravity.CENTER); play.setBackground(roundBg(RED,12)); card.addView(play,new LinearLayout.LayoutParams(dp(52),dp(52)));
        TextView name=text(title,18,true,Color.WHITE); name.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); card.addView(name,new LinearLayout.LayoutParams(0,dp(62),1f));
        play.setOnClickListener(v->toggleTrack(resId,play));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(0,dp(6),0,dp(6)); page.addView(card,lp);
    }

    private void toggleTrack(int resId,TextView button){
        if(player!=null && activeButton==button){
            if(player.isPlaying()){player.pause();button.setText("▶");} else {player.start();button.setText("⏸");}
            return;
        }
        stopPlayer(); player=MediaPlayer.create(this,resId); activeButton=button;
        if(player==null){Toast.makeText(this,"تعذر تشغيل الصوت",Toast.LENGTH_SHORT).show();return;}
        button.setText("⏸"); player.setOnCompletionListener(mp->{button.setText("▶");stopPlayer();}); player.start();
    }

    private void stopPlayer(){
        if(player!=null){try{player.stop();}catch(Exception ignored){} player.release(); player=null;}
        if(activeButton!=null){activeButton.setText("▶"); activeButton=null;}
    }

    private GradientDrawable roundBg(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private TextView text(String s,int size,boolean bold,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setPadding(dp(8),dp(8),dp(8),dp(8));v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    @Override protected void onStop(){super.onStop();stopPlayer();}
    @Override protected void onDestroy(){stopPlayer();super.onDestroy();}
}
