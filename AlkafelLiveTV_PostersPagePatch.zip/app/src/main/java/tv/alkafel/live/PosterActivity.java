package tv.alkafel.live;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class PosterActivity extends Activity {

    private static final int BG = Color.rgb(5, 5, 5);
    private static final int RED = Color.rgb(170, 0, 0);
    private static final int GOLD = Color.rgb(210, 170, 75);

    private final String[] titles = {
            "إعلان القناة",
            "انطلاقة جديدة",
            "تطبيق الكافل الفضائية"
    };

    private final String[] resources = {
            "poster_app_1",
            "poster_youtube",
            "poster_app_2"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(12), dp(14), dp(12), dp(24));
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(page);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = text("‹", 30, true, Color.WHITE);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        TextView title = text("إعلانات القناة", 24, true, Color.WHITE);
        title.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(58), 1f));
        page.addView(top);

        TextView subtitle = text("بوسترات قناة الكافل الفضائية", 13, false, GOLD);
        subtitle.setGravity(Gravity.RIGHT);
        page.addView(subtitle);

        int selected = getIntent().getIntExtra("poster_index", -1);

        for (int i = 0; i < resources.length; i++) {
            addPoster(page, titles[i], resources[i], i == selected);
        }

        setContentView(scroll);

        if (selected >= 0 && selected < resources.length) {
            // Keep the selected poster near the top when opened from a card.
            page.post(() -> {
                View target = page.getChildAt(Math.min(3 + selected, page.getChildCount() - 1));
                if (target != null) target.requestFocus();
            });
        }
    }

    private void addPoster(LinearLayout page, String title, String resourceName, boolean selected) {
        TextView label = text(title, 16, true, selected ? Color.WHITE : GOLD);
        label.setGravity(Gravity.RIGHT);
        label.setPadding(dp(8), dp(10), dp(8), dp(6));
        page.addView(label);

        ImageView image = new ImageView(this);
        int id = getResources().getIdentifier(resourceName, "drawable", getPackageName());
        image.setImageResource(id);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setBackgroundColor(Color.BLACK);
        image.setAdjustViewBounds(true);
        image.setContentDescription(title);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(18));
        image.setPadding(dp(2), dp(2), dp(2), dp(2));
        page.addView(image, lp);
    }

    private TextView text(String s, int size, boolean bold, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(dp(8), dp(8), dp(8), dp(8));
        v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return v;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
