package tv.abbassia.live;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

public class MainActivity extends Activity {
    private static final String STREAM_URL = "https://ch14.tv/live/5net/abbassia.m3u8";
    private ExoPlayer player;
    private PlayerView playerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.BLACK);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 24, 18, 30);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);

        TextView title = text("الكافل الفضائية", 28, true);
        title.setTextColor(Color.WHITE);
        root.addView(title);

        TextView sub = text("AL-KAFEL TV", 13, false);
        sub.setTextColor(0xFFBFBFBF);
        root.addView(sub);

        // Live channel starts automatically as soon as the app opens.
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams videoLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(220));
        videoLp.setMargins(0, 20, 0, 12);
        playerView.setLayoutParams(videoLp);
        root.addView(playerView);

        TextView live = card("🔴  مباشر الآن  •  البث المباشر");
        live.setTextColor(0xFFFFD4D4);
        root.addView(live);

        LinearLayout shortcuts = new LinearLayout(this);
        shortcuts.setOrientation(LinearLayout.HORIZONTAL);
        shortcuts.setGravity(Gravity.CENTER);
        shortcuts.setWeightSum(4f);
        String[] items = {"الخطباء", "المجالس", "جدول البث", "المفضلة"};
        for (String s : items) {
            TextView v = card(s);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(80), 1f);
            lp.setMargins(5, 6, 5, 6);
            v.setLayoutParams(lp);
            shortcuts.addView(v);
        }
        root.addView(shortcuts);

        TextView ticker = card("أخبار وتنويهات قناة الكافل الفضائية");
        ticker.setTextColor(0xFFFFC7C7);
        root.addView(ticker);

        root.addView(section("الإعلانات والبوسترات"));
        root.addView(card("مساحة البوسترات والإعلانات"));

        root.addView(section("مواقيت الصلاة"));
        root.addView(card("البحرين - المنامة\nالفجر • الشروق • الظهر • العصر • المغرب • العشاء"));

        root.addView(section("التواصل الاجتماعي"));
        root.addView(card("YouTube   •   Facebook   •   Instagram   •   Telegram   •   WhatsApp"));

        setContentView(scroll);
        startPlayer();
    }

    private void startPlayer() {
        if (player != null) return;
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(Uri.parse(STREAM_URL)));
        player.setPlayWhenReady(true);
        player.prepare();
        player.play();
    }

    private TextView section(String s) {
        TextView v = text(s, 21, true);
        v.setGravity(Gravity.RIGHT);
        v.setPadding(6, 24, 6, 6);
        return v;
    }

    private TextView text(String s, int size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setGravity(Gravity.CENTER);
        v.setTextColor(Color.WHITE);
        v.setPadding(12, 12, 12, 12);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private TextView card(String s) {
        TextView v = text(s, 16, true);
        v.setBackgroundColor(0xFF181818);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 7, 0, 7);
        v.setLayoutParams(lp);
        v.setMinHeight(dp(58));
        return v;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (player == null && playerView != null) startPlayer();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
